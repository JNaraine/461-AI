using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Leon : MonoBehaviour
{
    public GameObject text;
    Color mouseOver = Color.blue;

    Color orginalColor;

    MeshRenderer renderer;

    public void Start()
    {
        renderer = GetComponent<MeshRenderer>();
        orginalColor = renderer.material.color;
        text.SetActive(false);

    }

    public void OnMouseOver()
    {
        renderer.material.color = mouseOver;
        text.SetActive(true);
    }

    public void OnMouseExit()
    {
        renderer.material.color = orginalColor;
        text.SetActive(false);
    }
}
